<?php
include '../bd.php';
session_start();



echo json_encode($elementos);
        